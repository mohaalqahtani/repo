//
//  CLGPUImageVignetteFilter.h
//
//  Created by sho yakushiji on 2014/01/28.
//  Copyright (c) 2014年 CALACULU. All rights reserved.
//

#if __has_include("GPUImage.h")

#import "CLFilterBase.h"

@interface CLGPUImageVignetteFilter : CLFilterBase

@end

#endif