//
//  UIDevice+SystemVersion.h
//
//  Created by sho yakushiji on 2013/11/06.
//  Copyright (c) 2013年 CALACULU. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIDevice (SystemVersion)

+ (CGFloat)iosVersion;

@end
