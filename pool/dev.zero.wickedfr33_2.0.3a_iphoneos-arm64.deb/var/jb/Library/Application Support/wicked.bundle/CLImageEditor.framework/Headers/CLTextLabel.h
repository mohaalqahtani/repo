//
//  CLTextLabel.h
//
//  Created by sho yakushiji on 2013/12/16.
//  Copyright (c) 2013年 CALACULU. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CLTextLabel : UILabel

@property (nonatomic, strong) UIColor *outlineColor;
@property (nonatomic, assign) CGFloat outlineWidth;

@end
